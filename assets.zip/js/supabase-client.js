/**
 * Safe Space - Supabase Database & Auth Client Layer
 * Handles Supabase initialization, queries, auth, storage, and local demo fallback.
 */

// Initial Seed Data for Demo / Offline Laptop mode
var INITIAL_DEMO_DATA = {
  currentUser: {
    id: "user-demo-1",
    email: "demo@safespace.org",
    username: "alex_rivera",
    first_name: "Alex",
    last_name: "Rivera",
    age: 21,
    sex: "Non-binary",
    birthday: "2003-05-14",
    bio: "Living authentically 🌈 Psychology student, artist, and LGBTQ+ advocate.",
    avatar_url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
  },
  members: [
    {
      id: "user-demo-2",
      username: "jordan_lee",
      first_name: "Jordan",
      last_name: "Lee",
      bio: "Here to listen, learn, and share safe warmth. Proud trans ally.",
      avatar_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "user-demo-3",
      username: "taylor_sky",
      first_name: "Taylor",
      last_name: "Sky",
      bio: "Trans and thriving ✨ You are not alone.",
      avatar_url: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "support-counselor-1",
      username: "counselor_sam",
      first_name: "Sam (Counselor)",
      last_name: "Support",
      bio: "Certified Peer Counselor available 24/7 for safe chat & mental health support.",
      avatar_url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80",
      isSupport: true
    }
  ],
  posts: [
    {
      id: "post-1",
      user_id: "user-demo-2",
      author_name: "jordan_lee",
      author_avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
      content: "Reminder to everyone in this community: your journey is valid, your identity is precious, and you deserve unconditional respect. Never let anyone dim your rainbow! 🌈✨",
      mood: "love",
      photo_url: null,
      is_anonymous: false,
      likes: ["user-demo-1"],
      comments: [
        { id: "c-1", user_id: "user-demo-1", username: "alex_rivera", content: "Thank you so much for this reminder today!", created_at: "10 mins ago" }
      ],
      created_at: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: "post-2",
      user_id: "user-demo-3",
      author_name: "Anonymous",
      author_avatar: null,
      content: "Came out to my closest friends this weekend after months of anxiety. They prepared a small rainbow cake and hugged me. Still crying happy tears! 😭❤️",
      mood: "haha",
      photo_url: "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=600&q=80",
      is_anonymous: true,
      likes: ["user-demo-1", "user-demo-2"],
      comments: [
        { id: "c-2", user_id: "user-demo-2", username: "jordan_lee", content: "So incredibly proud of you! Welcome to living in full color!", created_at: "25 mins ago" }
      ],
      created_at: new Date(Date.now() - 14400000).toISOString()
    },
    {
      id: "post-3",
      user_id: "user-demo-1",
      author_name: "alex_rivera",
      author_avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80",
      content: "Feeling a bit overwhelmed with final exams and family pressure lately. Taking deep breaths and listening to calming music. How do you all ground yourselves during stress?",
      mood: "sad",
      photo_url: null,
      is_anonymous: false,
      likes: ["user-demo-3"],
      comments: [
        { id: "c-3", user_id: "support-counselor-1", username: "counselor_sam", content: "The 5-4-3-2-1 sensory grounding exercise is wonderfully effective! We are here if you'd like to chat 1-on-1.", created_at: "1 hour ago" }
      ],
      created_at: new Date(Date.now() - 28800000).toISOString()
    }
  ],
  messages: [
    {
      id: "m-1",
      sender_id: "support-counselor-1",
      receiver_id: "user-demo-1",
      message: "Hello Alex! Welcome to Safe Space Support Chat. How are you feeling today?",
      created_at: new Date(Date.now() - 7200000).toISOString()
    },
    {
      id: "m-2",
      sender_id: "user-demo-1",
      receiver_id: "support-counselor-1",
      message: "Hi Sam! Thanks for reaching out. Feeling better after reading the community posts!",
      created_at: new Date(Date.now() - 3600000).toISOString()
    }
  ],
  friendships: [
    { id: "f-1", requester_id: "user-demo-2", receiver_id: "user-demo-1", status: "accepted" },
    { id: "f-2", requester_id: "user-demo-3", receiver_id: "user-demo-1", status: "pending" }
  ],
  savedPosts: ["post-1"],
  blocks: []
};

// Initialize Local Storage if empty (posts/members/messages only — NOT user, must login)
function initLocalStorage() {
  if (!localStorage.getItem('safe_space_posts')) {
    localStorage.setItem('safe_space_posts', JSON.stringify(INITIAL_DEMO_DATA.posts));
  }
  if (!localStorage.getItem('safe_space_members')) {
    localStorage.setItem('safe_space_members', JSON.stringify(INITIAL_DEMO_DATA.members));
  }
  if (!localStorage.getItem('safe_space_messages')) {
    localStorage.setItem('safe_space_messages', JSON.stringify(INITIAL_DEMO_DATA.messages));
  }
  if (!localStorage.getItem('safe_space_saved')) {
    localStorage.setItem('safe_space_saved', JSON.stringify(INITIAL_DEMO_DATA.savedPosts || []));
  }
  if (!localStorage.getItem('safe_space_friendships')) {
    localStorage.setItem('safe_space_friendships', JSON.stringify(INITIAL_DEMO_DATA.friendships || []));
  }
}

initLocalStorage();

// ─────────────────────────────────────────────────────────────────
// Initialize Supabase Client
// Uses "_db" internally to avoid clashing with any global
// ─────────────────────────────────────────────────────────────────
var _db = null;
(function initSupabase() {
  try {
    var configured = typeof SAFE_SPACE_CONFIG !== 'undefined' && SAFE_SPACE_CONFIG.isConfigured();
    var sbLib = (typeof window !== 'undefined' && window.supabase && typeof window.supabase.createClient === 'function')
      ? window.supabase
      : null;
    if (configured && sbLib) {
      _db = sbLib.createClient(
        SAFE_SPACE_CONFIG.SUPABASE_URL,
        SAFE_SPACE_CONFIG.SUPABASE_ANON_KEY
      );
      console.log('[SafeSpace] ✅ Connected to Supabase:', SAFE_SPACE_CONFIG.SUPABASE_URL);
    } else if (!sbLib) {
      console.warn('[SafeSpace] ⚠️ Supabase library not available — running in Demo/Local mode');
    } else {
      console.warn('[SafeSpace] ⚠️ Supabase not configured — running in Demo/Local mode');
    }
  } catch (err) {
    console.warn('[SafeSpace] Supabase init error, falling back to local mode:', err);
  }
})();

/**
 * High Level Unified SafeSpace API
 */
var SafeSpaceDB = {
  isSupabaseActive: function() {
    return Boolean(_db);
  },

  // ==========================================
  // AUTHENTICATION
  // ==========================================
  auth: {
    getCurrentUser: async function() {
      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.auth.getUser();
        var user = res.data ? res.data.user : null;
        if (!user) return null;
        var pRes = await _db.from('profiles').select('*').eq('id', user.id).single();
        var profile = pRes.data || {};
        return Object.assign({}, user, profile);
      }
      return JSON.parse(localStorage.getItem('safe_space_user'));
    },

    signIn: async function(email, password) {
      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.auth.signInWithPassword({ email: email, password: password });
        if (res.error) throw res.error;
        return res.data;
      }
      // Demo authentication
      if (!email || !password) throw new Error('Please enter email and password.');
      var stored = JSON.parse(localStorage.getItem('safe_space_user'));
      var baseUser = stored || Object.assign({}, INITIAL_DEMO_DATA.currentUser);
      baseUser.email = email;
      localStorage.setItem('safe_space_user', JSON.stringify(baseUser));
      return { user: baseUser };
    },

    signUp: async function(payload) {
      payload = payload || {};
      var email = payload.email;
      var password = payload.password;
      var metadata = Object.assign({}, payload);
      delete metadata.email;
      delete metadata.password;

      if (SafeSpaceDB.isSupabaseActive()) {
        // If REQUIRE_EMAIL_CONFIRMATION is enabled, use standard Supabase signup to trigger real SMTP confirmation email
        if (typeof SAFE_SPACE_CONFIG !== 'undefined' && SAFE_SPACE_CONFIG.REQUIRE_EMAIL_CONFIRMATION) {
          var res = await _db.auth.signUp({
            email: email,
            password: password,
            options: { data: metadata }
          });
          if (res.error) {
            // Provide a clear explanation if SMTP is not configured in Supabase yet
            if (res.error.message && res.error.message.toLowerCase().includes('confirmation email')) {
              throw new Error('Supabase SMTP Error: Please configure custom SMTP (Resend or Gmail) in your Supabase Dashboard -> Authentication -> SMTP Settings, or disable email confirmation.');
            }
            throw res.error;
          }
          // If waiting for email confirmation
          if (res.data && res.data.user && !res.data.session) {
            return {
              user: res.data.user,
              session: null,
              needsEmailConfirmation: true,
              email: email
            };
          }
          return res.data;
        }

        // Auto-confirm fallback via Admin API (when REQUIRE_EMAIL_CONFIRMATION is false)
        if (typeof SAFE_SPACE_CONFIG !== 'undefined' && SAFE_SPACE_CONFIG.SUPABASE_SERVICE_KEY) {
          try {
            var adminUrl = SAFE_SPACE_CONFIG.SUPABASE_URL + '/auth/v1/admin/users';
            var response = await fetch(adminUrl, {
              method: 'POST',
              headers: {
                'apikey': SAFE_SPACE_CONFIG.SUPABASE_SERVICE_KEY,
                'Authorization': 'Bearer ' + SAFE_SPACE_CONFIG.SUPABASE_SERVICE_KEY,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                email: email,
                password: password,
                email_confirm: true,
                user_metadata: metadata
              })
            });

            var adminData = await response.json();
            if (!response.ok) {
              var errMessage = adminData.msg || adminData.message || adminData.error_description || 'Registration error';
              throw new Error(errMessage);
            }

            var loginRes = await _db.auth.signInWithPassword({ email: email, password: password });
            if (loginRes.error) throw loginRes.error;
            return loginRes.data;
          } catch (adminErr) {
            console.warn('[SafeSpace] Admin auto-confirm signup error:', adminErr);
            throw adminErr;
          }
        }
      }
      // Demo Signup
      var newUser = {
        id: 'user-' + Date.now(),
        email: email,
        username: metadata.username || (email ? email.split('@')[0] : 'user'),
        first_name: metadata.first_name || 'Member',
        middle_name: metadata.middle_name || null,
        last_name: metadata.last_name || '',
        age: metadata.age || null,
        sex: metadata.sex || null,
        birthday: metadata.birthday || null,
        bio: metadata.bio || 'Hello, Safe Space!',
        avatar_url: metadata.avatar_url || null,
        created_at: new Date().toISOString()
      };
      localStorage.setItem('safe_space_user', JSON.stringify(newUser));
      return { user: newUser };
    },

    updateProfile: async function(updates) {
      updates = updates || {};
      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.auth.getUser();
        var user = res.data ? res.data.user : null;
        if (!user) throw new Error('Not logged in');
        var pRes = await _db
          .from('profiles')
          .update(Object.assign({}, updates, { updated_at: new Date().toISOString() }))
          .eq('id', user.id)
          .select()
          .single();
        if (pRes.error) throw pRes.error;
        return pRes.data;
      }
      var cur = JSON.parse(localStorage.getItem('safe_space_user')) || {};
      var updatedUser = Object.assign({}, cur, updates);
      localStorage.setItem('safe_space_user', JSON.stringify(updatedUser));
      return updatedUser;
    },

    signOut: async function() {
      if (SafeSpaceDB.isSupabaseActive()) {
        try { await _db.auth.signOut(); } catch (e) {}
      }
      localStorage.removeItem('safe_space_user');
      localStorage.removeItem('safe_space_session_active');
    }
  },

  // ==========================================
  // POSTS & COMMUNITY FEED
  // ==========================================
  posts: {
    getFeed: async function(filter) {
      filter = filter || {};
      if (SafeSpaceDB.isSupabaseActive()) {
        var query = _db.from('posts').select(`
          *,
          profiles:user_id (id, username, avatar_url),
          post_likes (user_id),
          post_comments (id, user_id, content, created_at, profiles:user_id(username, avatar_url))
        `).order('created_at', { ascending: false });

        if (filter.mood) query = query.eq('mood', filter.mood);
        if (filter.userId) query = query.eq('user_id', filter.userId);

        var res = await query;
        if (res.error) throw res.error;
        return (res.data || []).map(function(p) {
          return Object.assign({}, p, {
            author_name: p.is_anonymous ? 'Anonymous' : (p.profiles ? p.profiles.username : 'Member'),
            author_avatar: p.is_anonymous ? null : (p.profiles ? p.profiles.avatar_url : null),
            likes: p.post_likes ? p.post_likes.map(function(l) { return l.user_id; }) : [],
            comments: p.post_comments || []
          });
        });
      }

      var posts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      if (filter.mood) posts = posts.filter(function(p) { return p.mood === filter.mood; });
      if (filter.userId) posts = posts.filter(function(p) { return p.user_id === filter.userId; });
      return posts;
    },

    createPost: async function(options) {
      var content = options.content;
      var mood = options.mood || null;
      var photo_url = options.photo_url || null;
      var is_anonymous = Boolean(options.is_anonymous);

      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) throw new Error('You must be logged in to post.');

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('posts').insert({
          user_id: currentUser.id,
          content: content,
          mood: mood,
          photo_url: photo_url,
          is_anonymous: is_anonymous
        }).select().single();
        if (res.error) throw res.error;
        return res.data;
      }

      var posts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      var newPost = {
        id: 'post-' + Date.now(),
        user_id: currentUser.id,
        author_name: is_anonymous ? 'Anonymous' : currentUser.username,
        author_avatar: is_anonymous ? null : currentUser.avatar_url,
        content: content,
        mood: mood,
        photo_url: photo_url,
        is_anonymous: is_anonymous,
        likes: [],
        comments: [],
        created_at: new Date().toISOString()
      };
      posts.unshift(newPost);
      localStorage.setItem('safe_space_posts', JSON.stringify(posts));
      return newPost;
    },

    toggleLike: async function(postId) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return false;

      if (SafeSpaceDB.isSupabaseActive()) {
        var existingRes = await _db.from('post_likes')
          .select('id').eq('post_id', postId).eq('user_id', currentUser.id).maybeSingle();
        if (existingRes.data) {
          await _db.from('post_likes').delete().eq('id', existingRes.data.id);
          return false;
        } else {
          await _db.from('post_likes').insert({ post_id: postId, user_id: currentUser.id });
          return true;
        }
      }

      var posts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      var post = posts.find(function(p) { return p.id === postId; });
      if (!post) return false;
      var idx = post.likes.indexOf(currentUser.id);
      var liked = false;
      if (idx > -1) {
        post.likes.splice(idx, 1);
      } else {
        post.likes.push(currentUser.id);
        liked = true;
      }
      localStorage.setItem('safe_space_posts', JSON.stringify(posts));
      return liked;
    },

    addComment: async function(postId, content) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) throw new Error('Log in to comment.');

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('post_comments').insert({
          post_id: postId,
          user_id: currentUser.id,
          content: content
        }).select(`*, profiles:user_id(username, avatar_url)`).single();
        if (res.error) throw res.error;
        return res.data;
      }

      var posts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      var post = posts.find(function(p) { return p.id === postId; });
      if (!post) throw new Error('Post not found');
      var comment = {
        id: 'c-' + Date.now(),
        user_id: currentUser.id,
        username: currentUser.username,
        content: content,
        created_at: 'Just now'
      };
      post.comments.push(comment);
      localStorage.setItem('safe_space_posts', JSON.stringify(posts));
      return comment;
    },

    toggleSave: async function(postId) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return false;

      if (SafeSpaceDB.isSupabaseActive()) {
        var existingRes = await _db.from('saved_posts')
          .select('id').eq('post_id', postId).eq('user_id', currentUser.id).maybeSingle();
        if (existingRes.data) {
          await _db.from('saved_posts').delete().eq('id', existingRes.data.id);
          return false;
        } else {
          await _db.from('saved_posts').insert({ post_id: postId, user_id: currentUser.id });
          return true;
        }
      }

      var saved = JSON.parse(localStorage.getItem('safe_space_saved')) || [];
      var idx = saved.indexOf(postId);
      var isSaved = false;
      if (idx > -1) {
        saved.splice(idx, 1);
      } else {
        saved.push(postId);
        isSaved = true;
      }
      localStorage.setItem('safe_space_saved', JSON.stringify(saved));
      return isSaved;
    },

    getSavedPosts: async function() {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return [];

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('saved_posts')
          .select('post_id, posts(*, profiles:user_id(username, avatar_url))')
          .eq('user_id', currentUser.id);
        return res.data ? res.data.map(function(d) { return d.posts; }) : [];
      }

      var saved = JSON.parse(localStorage.getItem('safe_space_saved')) || [];
      var allPosts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      return allPosts.filter(function(p) { return saved.includes(p.id); });
    },

    deletePost: async function(postId) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return;

      if (SafeSpaceDB.isSupabaseActive()) {
        await _db.from('posts').delete().eq('id', postId).eq('user_id', currentUser.id);
        return;
      }

      var posts = JSON.parse(localStorage.getItem('safe_space_posts')) || [];
      posts = posts.filter(function(p) { return p.id !== postId; });
      localStorage.setItem('safe_space_posts', JSON.stringify(posts));
    }
  },

  // ==========================================
  // MESSAGING & CHAT SUPPORT
  // ==========================================
  messages: {
    getConversations: async function() {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return [];

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('messages')
          .select(`*, sender:sender_id(id, username, avatar_url), receiver:receiver_id(id, username, avatar_url)`)
          .or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
          .order('created_at', { ascending: false });
        return res.data || [];
      }

      return JSON.parse(localStorage.getItem('safe_space_messages')) || [];
    },

    getMessagesWith: async function(otherUserId) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return [];

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('messages')
          .select('*')
          .or(`and(sender_id.eq.${currentUser.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${currentUser.id})`)
          .order('created_at', { ascending: true });
        return res.data || [];
      }

      var all = JSON.parse(localStorage.getItem('safe_space_messages')) || [];
      return all.filter(function(m) {
        return (m.sender_id === currentUser.id && m.receiver_id === otherUserId) ||
               (m.sender_id === otherUserId && m.receiver_id === currentUser.id);
      });
    },

    sendMessage: async function(receiverId, text) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) throw new Error('Not authenticated');

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('messages').insert({
          sender_id: currentUser.id,
          receiver_id: receiverId,
          message: text
        }).select().single();
        if (res.error) throw res.error;
        return res.data;
      }

      var messages = JSON.parse(localStorage.getItem('safe_space_messages')) || [];
      var msg = {
        id: 'msg-' + Date.now(),
        sender_id: currentUser.id,
        receiver_id: receiverId,
        message: text,
        created_at: new Date().toISOString()
      };
      messages.push(msg);
      localStorage.setItem('safe_space_messages', JSON.stringify(messages));
      return msg;
    }
  },

  // ==========================================
  // COMMUNITY MEMBERS & CONNECTIONS
  // ==========================================
  community: {
    getMembers: async function(query) {
      query = query || '';
      if (SafeSpaceDB.isSupabaseActive()) {
        var q = _db.from('profiles').select('*');
        if (query) q = q.ilike('username', `%${query}%`);
        var res = await q;
        return res.data || [];
      }

      var members = JSON.parse(localStorage.getItem('safe_space_members')) || [];
      if (query) {
        members = members.filter(function(m) {
          return m.username && m.username.toLowerCase().includes(query.toLowerCase());
        });
      }
      return members;
    },

    getFriendships: async function() {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return [];

      if (SafeSpaceDB.isSupabaseActive()) {
        var res = await _db.from('friendships')
          .select('*')
          .or(`requester_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`);
        return res.data || [];
      }

      return JSON.parse(localStorage.getItem('safe_space_friendships')) || [];
    },

    sendFriendRequest: async function(targetId) {
      var currentUser = await SafeSpaceDB.auth.getCurrentUser();
      if (!currentUser) return;

      if (SafeSpaceDB.isSupabaseActive()) {
        await _db.from('friendships').insert({
          requester_id: currentUser.id,
          receiver_id: targetId,
          status: 'pending'
        });
        return;
      }

      var friendships = JSON.parse(localStorage.getItem('safe_space_friendships')) || [];
      friendships.push({
        id: 'f-' + Date.now(),
        requester_id: currentUser.id,
        receiver_id: targetId,
        status: 'pending'
      });
      localStorage.setItem('safe_space_friendships', JSON.stringify(friendships));
    }
  },

  // ==========================================
  // STORAGE & IMAGE UPLOADS
  // ==========================================
  storage: {
    uploadImage: async function(file, bucket) {
      bucket = bucket || 'post-photos';
      if (SafeSpaceDB.isSupabaseActive()) {
        var fileExt = file.name ? file.name.split('.').pop() : 'jpg';
        var fileName = Date.now() + '_' + Math.random().toString(36).substring(2) + '.' + fileExt;
        var upRes = await _db.storage.from(bucket).upload(fileName, file);
        if (upRes.error) throw upRes.error;
        var pubRes = _db.storage.from(bucket).getPublicUrl(fileName);
        return pubRes.data ? pubRes.data.publicUrl : null;
      }

      return new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.onload = function() { resolve(reader.result); };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
  }
};

if (typeof window !== 'undefined') {
  window.SafeSpaceDB = SafeSpaceDB;
}
